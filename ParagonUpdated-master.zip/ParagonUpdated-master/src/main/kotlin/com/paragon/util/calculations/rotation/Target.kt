package com.paragon.util.calculations.rotation

/**
 * @author aesthetical
 * @since 02/17/23
 */
enum class Target {
    HEAD,
    TORSO,
    LEGS,
    FEET
}