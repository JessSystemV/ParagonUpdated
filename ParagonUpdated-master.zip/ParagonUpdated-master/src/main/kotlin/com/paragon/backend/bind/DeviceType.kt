package com.paragon.backend.bind

/**
 * @author aesthetical
 * @since 02/17/23
 */
enum class DeviceType {
    KEYBOARD,
    MOUSE,
    UNKNOWN
}