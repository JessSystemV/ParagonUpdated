package com.paragon.backend.event

/**
 * @author surge
 * @since 19/02/2023
 */
enum class EventEra {
    PRE,
    POST
}