package com.paragon.client.toasts

/**
 * @author aesthetical
 * @since 02/19/23
 */
enum class ToastType {
    INFO,
    SUCCESS,
    WARNING,
    ERROR
}