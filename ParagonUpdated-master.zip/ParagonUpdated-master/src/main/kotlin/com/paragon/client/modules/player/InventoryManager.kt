package com.paragon.client.modules.player

object InventoryManager {
}