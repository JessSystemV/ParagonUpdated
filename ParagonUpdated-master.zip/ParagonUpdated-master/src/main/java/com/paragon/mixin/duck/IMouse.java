package com.paragon.mixin.duck;

/**
 * @author surge
 * @since 24/02/2023
 */
public interface IMouse {

    double getScrollDelta();

}
