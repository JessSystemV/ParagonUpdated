# paragon updated
paragon for the latest version of minecraft

uses fabric, needs fabric api